<?php
$scriptName = '/catalog/api-proxy.php';
$uri = $_SERVER['REQUEST_URI'] ?? '';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($uri, PHP_URL_PATH) ?: '';
$pos = strpos($path, $scriptName);
if ($pos !== false) { $path = substr($path, $pos + strlen($scriptName)); }
if ($path === '' || $path === false) { $path = '/api/siteContext'; }
if (strpos($path, '/api/') !== 0) {
  http_response_code(400); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['error'=>'Invalid API path']); exit;
}
$target = 'https://site-pro-api.nmarket.pro' . $path;
$q = $_SERVER['QUERY_STRING'] ?? '';
if ($q !== '') { $target .= '?' . $q; }
$ch = curl_init($target);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 45);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
$headers = ['Accept: application/json', 'Origin: http://novostroy-market.allrealty.pro', 'Referer: http://novostroy-market.allrealty.pro/'];
$ct = $_SERVER['CONTENT_TYPE'] ?? '';
if ($ct !== '') { $headers[] = 'Content-Type: ' . $ct; }
if (in_array($method, ['POST','PUT','PATCH','DELETE'], true)) {
  $body = file_get_contents('php://input');
  curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
}
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
if ($resp === false) {
  $err = curl_error($ch); curl_close($ch);
  http_response_code(502); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['error'=>'Proxy failed','details'=>$err]); exit;
}
curl_close($ch);
http_response_code($status ?: 200);
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Cache-Control: no-store');
header('Content-Type: ' . ($ctype ?: 'application/json; charset=utf-8'));
echo $resp;

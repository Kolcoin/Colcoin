Install to /public_html with overwrite.
Open /catalog/ and /catalog/commercial/.
If host blocks proxy requests, keep Origin/Referer headers in api-proxy.php as shipped.

SAFE IMPORT PACKAGE

Что внутри:
- seo/*.html (без PHP, без админки, без базы)
- assets/img/safe-import/* (картинки, которые удалось найти)
- sitemap-safe-import.xml (карта только для этих импортированных страниц)
- safe-import-manifest.json (сопоставление исходных URL и новых slug)

Что НЕ включено:
- .htaccess
- config.php / index.php / любые php-роутеры
- mina54/admin.php
- site_database.sqlite
- любые служебные и потенциально рискованные файлы

Установка:
1) Загрузить содержимое архива в /public_html (с сохранением структуры папок).
2) Добавить URL из sitemap-safe-import.xml в основную карту сайта при необходимости.
3) Проверить выборочно 5-10 URL из safe-import-manifest.json.

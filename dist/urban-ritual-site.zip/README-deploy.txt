УСТАНОВКА urban-ritual.ru — 715 страниц + Sitemap Index
=========================================================

1. Бэкап старого public_html (Сжать → Скачать)
2. Удали всё из public_html
3. Загрузи urban-ritual-site.zip и распакуй
4. Удали zip
5. Ctrl+Shift+R в браузере

КАРТЫ САЙТА (sitemap):
- /sitemap.xml — главный индекс
- /sitemap-main.xml         (1 URL — главная)
- /sitemap-rayon.xml        (12 URL — микрорайоны Химок)
- /sitemap-city.xml         (73 URL — города МО)
- /sitemap-settlement.xml   (401 URL — НП Подмосковья)
- /sitemap-moscow.xml       (146 URL — АО и районы Москвы)
- /sitemap-cemetery.xml     (82 URL — кладбища, крематории, морги)

В ЯНДЕКС.ВЕБМАСТЕР И GOOGLE SEARCH CONSOLE
вставлять можно ОДНУ ссылку — главный индекс:

https://urban-ritual.ru/sitemap.xml

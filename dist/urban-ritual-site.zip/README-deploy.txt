ОБНОВЛЕНИЕ urban-ritual.ru — реальный e-mail клиента
=====================================================

ИЗМЕНЕНИЯ В ЭТОЙ ВЕРСИИ:
- Все формы заявок теперь шлют письма на: direkt.ritual@yandex.ru
- Этот же e-mail указан в разделе "Контакты"
- Старый info@urban-ritual.ru удалён везде
- sitemap.xml + 6 подкарт обновлены с новой датой (lastmod 2026-05-12)

ВАЖНО — после заливки на Beget:

1. Открой почту direkt.ritual@yandex.ru (в Яндекс.Почте)

2. Зайди на urban-ritual.ru → раздел "Контакты"
   → заполни форму "Перезвоните мне" своими данными
   → нажми "Жду звонка"
   → жди зелёного "Спасибо!"

3. На direkt.ritual@yandex.ru придёт ПИСЬМО от FormSubmit с темой
   "[FormSubmit] Click activation link"
   с большой кнопкой "Activate". Нажми её — это разовое подтверждение.

4. После этого ВСЕ заявки с сайта будут автоматически
   прилетать на direkt.ritual@yandex.ru.

КАРТА САЙТА (для Я.Вебмастера и Google Search Console):
- https://urban-ritual.ru/sitemap.xml — главный индекс (715 URL)
- + 6 подкарт: main, rayon, city, settlement, moscow, cemetery
